from tkinter import *


class AdminDashboard:
    def __init__(self, root):
        self.root = root
        self.root.title("Admin Dashboard")

        img1 = PhotoImage(file="img/img4.png")
        pic1 = Label(image=img1, bg='#5A3737')
        pic1.photo = img1
        pic1.place(x=0, y=0)

        psr1 = PanedWindow(width=204, height=470, bg='#5A3737')
        psr1.place(x=0, y=375)

        users = Label(psr1, text='USERS', font='Inter 20', fg='white', bg='#5A3737')
        users.place(x=50,y=100)

        items = Label(psr1, text='ITEMS', font="Inter 20", fg='white',bg='#5A3737')
        items.place(x=55,y=175)

        orders = Label(psr1, text='ORDERS', font='Inter 20', fg='white', bg='#5A3737')
        orders.place(x=40, y=250)

        settings = Label(psr1, text='SETTINGS', font="Inter 20", fg='white', bg='#5A3737')
        settings. place(x=30,y=325)

        logout = Label(psr1, text='LOGOUT', font="Inter 20 bold", fg='white', bg='#5A3737')
        logout.place(x=40,y=400)

        psr2 = PanedWindow(width=1500, height=120, bg='#5A3737')
        psr2.place(x=203, y=0)

        img2 = PhotoImage(file="img/img1.png")
        logo1 = Label(image=img2, bg='#5A3737')
        logo1.photo = img2
        logo1.place(x=230, y=20)

        img3 = PhotoImage(file="img/Screenshot 2024-01-30 160342.png")
        logo2 = Label(psr2,image=img3, bg='#5A3737')
        logo2.photo = img3
        logo2.place(x=1200, y=20)

        username = Label(psr2, text="MG MG", bg="#5A3737", fg='white')
        username.config(font='Inter 15')
        username.place(x=1190, y=80)

        title = Label(text="UNIQUE TEAHOUSE", bg="#5A3737", fg='white')
        title.config(font='Inter 30 bold')
        title.place(x=320, y=35)

        p1 = PanedWindow(width=300, height=200, bg='silver')
        p1.place(x=230, y=150)

        t1 = Label(p1, text="5.3K USERS", bg='silver', fg='black', font='Inter 25 bold')
        t1.place(x=55,y=30)

        l1 = Label(p1, text="+241 USERS", bg='silver', fg='black', font='Inter 18')
        l1.place(x=70, y=70)

        i1 = Label(p1, text="^123 than previous month", bg='silver', fg='grey', font='Inter 18')
        i1.place(x=10, y=110)

        p2 = PanedWindow(width=300, height=200, bg='silver')
        p2.place(x=560, y=150)

        t2 = Label(p2, text="5K ORDERS", bg='silver', fg='black', font='Inter 25 bold')
        t2.place(x=55, y=30)

        l2 = Label(p2, text="+238 ORDERS", bg='silver', fg='black', font='Inter 18')
        l2.place(x=65, y=70)

        i2 = Label(p2, text="v25 than previous month", bg='silver', fg='grey', font='Inter 18')
        i2.place(x=15, y=110)

        p3 = PanedWindow(width=300, height=200, bg='silver')
        p3.place(x=890, y=150)

        t3 = Label(p3, text="8250K PROFIT", bg='silver', fg='black', font='Inter 25 bold')
        t3.place(x=40, y=30)

        l3 = Label(p3, text="+2050K PROFIT", bg='silver', fg='black', font='Inter 18')
        l3.place(x=60, y=70)

        i3 = Label(p3, text="v150K than previous month", bg='silver', fg='grey', font='Inter 18')
        i3.place(x=5, y=110)

        p4 = PanedWindow(width=300, height=200, bg='silver')
        p4.place(x=1220, y=150)

        t4 = Label(p4, text="LATTE", bg='silver', fg='#5A3737', font='Inter 28 bold')
        t4.place(x=90, y=30)

        l4 = Label(p4, text="Popular Now", bg='silver', fg='black', font='Inter 20 italic')
        l4.place(x=70, y=80)

        p5 = PanedWindow(width=400, height=270, bg='silver')
        p5.place(x=230, y=400)

        img4 = PhotoImage(file="img/Screenshot 2024-02-02 210448.png")
        pic2 = Label(p5, image=img4, bg='silver')
        pic2.photo = img4
        pic2.place(x=20, y=20)

        t5 = Label(p5, text="AVERAGE 20 MIN", bg='silver', fg='black', font='Inter 22 bold')
        t5.place(x=145, y=130)

        l5 = Label(p5, text="SCREENTIME THIS", bg='silver', fg='black', font='Inter 22 bold')
        l5.place(x=120, y=170)

        i5 = Label(p5, text='MONTH', bg='silver', fg='black', font='Inter 22 bold')
        i5.place(x=275, y=210)


if __name__ == "__main__":
    root = Tk()
    app = AdminDashboard(root)
    root.geometry("1920x1080")
    root.mainloop()