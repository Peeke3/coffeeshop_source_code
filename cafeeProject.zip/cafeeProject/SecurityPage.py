from tkinter import *


class SecurityPage:
    def __init__(self, root):
        self.root = root
        self.root.title("Security Page")

        p1 = PanedWindow(width=630,height=700,bg='#5A3737')
        p1.place(x=450,y=70)

        img1 = PhotoImage(file="img/img1.png")
        logo1 = Label(p1,image=img1, bg='#5A3737')
        logo1.photo = img1
        logo1.place(x=80, y=55)

        title = Label(p1,text="UNIQUE TEAHOUSE",bg="#5A3737",fg='white')
        title.config(font='Inter 30 bold')
        title.place(x=170, y=70)

        p2= PanedWindow(p1,width=400, height=200, bg='#6E4848')
        p2.place(x=115, y=350)

        title = Label(p2, text="ADMIN CODE", bg='#6E4848',fg='white')
        title.config(font='Inter 25 bold')
        title.place(x=90, y=50)

        e1=Entry(p2,width=13,font='Inter 30')
        e1.place(x=53,y=110)

        b1=Button(p1, text="I'M A USER", font='Inter 20 bold', fg='#5A3737')
        b1.place(x=70,y=560)

        b2 = Button(p1, text="CONTINUE", font='Inter 20 bold', fg='#5A3737')
        b2.place(x=390, y=560)


if __name__ == "__main__":
    root = Tk()
    app = SecurityPage(root)
    root.geometry("1920x1080")
    root.mainloop()