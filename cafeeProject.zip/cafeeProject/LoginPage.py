from tkinter import *


class LoginPage:
    def __init__(self, root):
        self.root = root
        self.root.title("Login Page")

        p1 = PanedWindow(width=500,height=602,bg='#5A3737')
        p1.place(x=740,y=130)

        img1 = PhotoImage(file="img/img1.png")
        logo1 = Label(image=img1, bg='white')
        logo1.photo = img1
        logo1.place(x=300, y=35)

        title = Label(text="UNIQUE TEAHOUSE",bg="white",fg='#5A3737')
        title.config(font='Inter 30 bold')
        title.place(x=390, y=50)

        img2 = PhotoImage(file='img/img2.png')
        pic1 = Label(image=img2, bg="#5A3737")
        pic1.photo = img2
        pic1.place(x=300,y=130)

        e1 = Entry(p1, width=17, font='Inter 28 bold')
        e1.place(x=75, y=150)

        e2 = Entry(p1, width=17, font='Inter 28 bold')
        e2.place(x=75, y=250)

        b1 = Button(p1, width=25, text='LOGIN', font='Inter 17 bold', fg='grey')
        b1.place(x=80, y=500)

        txt2 = Label(p1, text="FULL NAME", bg="#5A3737", fg='white')
        txt2.config(font='Inter 12')
        txt2.place(x=90, y=120)

        img4 = PhotoImage(file="img/img6.png")
        logo3 = Label(p1, image=img4, bg='#5A3737')
        logo3.photo = img4
        logo3.place(x=57, y=117)

        txt3 = Label(p1, text="USERNAME", bg="#5A3737", fg='white')
        txt3.config(font='Inter 12')
        txt3.place(x=90, y=220)

        img5 = PhotoImage(file="img/img6.png")
        logo4 = Label(p1, image=img5, bg='#5A3737')
        logo4.photo = img5
        logo4.place(x=57, y=217)


if __name__ == "__main__":
    root = Tk()
    app = LoginPage(root)
    root.geometry("1920x1080")
    root.mainloop()