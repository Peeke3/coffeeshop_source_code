from tkinter import *


class UserDashboard:
    def __init__(self, root):
        self.root = root
        self.root.title("User Dashboard")

        img1 = PhotoImage(file="img/img4.png")
        pic1 = Label(image=img1, bg='#5A3737')
        pic1.photo = img1
        pic1.place(x=0, y=0)

        psr1 = PanedWindow(width=204, height=470, bg='#5A3737')
        psr1.place(x=0, y=375)

        home = Label(psr1, text='HOME', font='Inter 20 bold', fg='white', bg='#5A3737')
        home.place(x=55,y=25)

        myorders = Label(psr1, text='MY ORDERS', font="Inter 20", fg='white',bg='#5A3737')
        myorders.place(x=18,y=300)

        settings = Label(psr1, text='SETTINGS', font="Inter 20", fg='white', bg='#5A3737')
        settings. place(x=30,y=350)

        logout = Label(psr1, text='LOGOUT', font="Inter 20 bold", fg='white', bg='#5A3737')
        logout.place(x=40,y=400)

        psr2 = PanedWindow(width=1500, height=120, bg='#5A3737')
        psr2.place(x=203, y=0)

        img2 = PhotoImage(file="img/img1.png")
        logo1 = Label(image=img2, bg='#5A3737')
        logo1.photo = img2
        logo1.place(x=230, y=20)

        img3 = PhotoImage(file="img/Screenshot 2024-01-30 160342.png")
        logo2 = Label(psr2,image=img3, bg='#5A3737')
        logo2.photo = img3
        logo2.place(x=1200, y=20)

        username = Label(psr2, text="MG MG", bg="#5A3737", fg='white')
        username.config(font='Inter 15')
        username.place(x=1190, y=80)

        title = Label(text="UNIQUE TEAHOUSE", bg="#5A3737", fg='white')
        title.config(font='Inter 30 bold')
        title.place(x=320, y=35)

        p1 = PanedWindow(width=200, height=250, bg='silver')
        p1.place(x=220, y=130)

        png1 = PhotoImage(file='img/latte-art.png')
        item1 = Label(p1, image=png1, bg='silver')
        item1.photo = png1
        item1.place(x=57,y=20)

        txt1 = Label(p1, text="Latte", bg="silver", fg='black')
        txt1.config(font='Inter 18')
        txt1.place(x=70, y=125)

        pt1 = Label(p1, text="Price > 2500", bg="silver", fg='black')
        pt1.config(font='Inter 18')
        pt1.place(x=30, y=155)

        btn1 = Button(p1, text="ADD TO CART", font='Inter 15 bold', fg='white', bg='#7E7E7E')
        btn1.place(x=22, y=190)

        p2 = PanedWindow(width=200, height=250, bg='silver')
        p2.place(x=440, y=130)

        png2 = PhotoImage(file='img/cappuccino.png')
        item2 = Label(p2, image=png2, bg='silver')
        item2.photo = png2
        item2.place(x=60, y=20)

        txt2 = Label(p2, text="Cappuccino", bg="silver", fg='black')
        txt2.config(font='Inter 18')
        txt2.place(x=35, y=125)

        pt2 = Label(p2, text="Price > 3000", bg="silver", fg='black')
        pt2.config(font='Inter 18')
        pt2.place(x=30, y=155)

        btn2 = Button(p2, text="ADD TO CART", font='Inter 15 bold', fg='white', bg='#7E7E7E')
        btn2.place(x=22, y=190)

        p3 = PanedWindow(width=200, height=250, bg='silver')
        p3.place(x=660, y=130)

        png3 = PhotoImage(file='img/coffee-cup.png')
        item3 = Label(p3, image=png3, bg='silver')
        item3.photo = png3
        item3.place(x=57, y=20)

        txt3 = Label(p3, text="Americano", bg="silver", fg='black')
        txt3.config(font='Inter 18')
        txt3.place(x=45, y=125)

        pt3 = Label(p3, text="Price > 3000", bg="silver", fg='black')
        pt3.config(font='Inter 18')
        pt3.place(x=30, y=155)

        btn3 = Button(p3, text="ADD TO CART", font='Inter 15 bold', fg='white', bg='#7E7E7E')
        btn3.place(x=22, y=190)

        p4 = PanedWindow(width=200, height=250, bg='silver')
        p4.place(x=880, y=130)

        png4 = PhotoImage(file='img/mocha.png')
        item4 = Label(p4, image=png4, bg='silver')
        item4.photo = png4
        item4.place(x=55, y=20)

        txt4 = Label(p4, text="Mocha", bg="silver", fg='black')
        txt4.config(font='Inter 18')
        txt4.place(x=60, y=125)

        pt4 = Label(p4, text="Price > 3500", bg="silver", fg='black')
        pt4.config(font='Inter 18')
        pt4.place(x=30, y=155)

        btn4 = Button(p4, text="ADD TO CART", font='Inter 15 bold', fg='white', bg='#7E7E7E')
        btn4.place(x=22, y=190)

        p5 = PanedWindow(width=200, height=250, bg='silver')
        p5.place(x=220, y=400)

        png5 = PhotoImage(file='img/chocolate-cake.png')
        item5 = Label(p5, image=png5, bg='silver')
        item5.photo = png5
        item5.place(x=50, y=10)

        txt5 = Label(p5, text="Chocolate cake", bg="silver", fg='black')
        txt5.config(font='Inter 18')
        txt5.place(x=12, y=125)

        pt5 = Label(p5, text="Price > 3000", bg="silver", fg='black')
        pt5.config(font='Inter 18')
        pt5.place(x=30, y=155)

        btn5 = Button(p5, text="ADD TO CART", font='Inter 15 bold', fg='white', bg='#7E7E7E')
        btn5.place(x=22, y=190)

        p6 = PanedWindow(width=200, height=250, bg='silver')
        p6.place(x=440, y=400)

        png6 = PhotoImage(file='img/strawberry-cake.png')
        item6 = Label(p6, image=png6, bg='silver')
        item6.photo = png6
        item6.place(x=50, y=10)

        txt6 = Label(p6, text="Strawberry cake", bg="silver", fg='black')
        txt6.config(font='Inter 18')
        txt6.place(x=12, y=125)

        pt6 = Label(p6, text="Price > 3500", bg="silver", fg='black')
        pt6.config(font='Inter 18')
        pt6.place(x=30, y=155)

        btn6 = Button(p6, text="ADD TO CART", font='Inter 15 bold', fg='white', bg='#7E7E7E')
        btn6.place(x=22, y=190)

        p7 = PanedWindow(width=200, height=250, bg='silver')
        p7.place(x=660, y=400)

        png7 = PhotoImage(file='img/cheese-cake.png')
        item7 = Label(p7, image=png7, bg='silver')
        item7.photo = png7
        item7.place(x=50, y=10)

        txt7 = Label(p7, text="Cheese cake", bg="silver", fg='black')
        txt7.config(font='Inter 18')
        txt7.place(x=25, y=125)

        pt7 = Label(p7, text="Price > 1500", bg="silver", fg='black')
        pt7.config(font='Inter 18')
        pt7.place(x=30, y=155)

        btn7 = Button(p7, text="ADD TO CART", font='Inter 15 bold', fg='white', bg='#7E7E7E')
        btn7.place(x=22, y=190)

        p8 = PanedWindow(width=200, height=250, bg='silver')
        p8.place(x=880, y=400)

        png8 = PhotoImage(file='img/carrot-cake.png')
        item8 = Label(p8, image=png8, bg='silver')
        item8.photo = png8
        item8.place(x=50, y=10)

        txt8 = Label(p8, text="Carrot cake", bg="silver", fg='black')
        txt8.config(font='Inter 18')
        txt8.place(x=32, y=125)

        pt8 = Label(p8, text="Price > 2000", bg="silver", fg='black')
        pt8.config(font='Inter 18')
        pt8.place(x=30, y=155)

        btn8 = Button(p8, text="ADD TO CART", font='Inter 15 bold', fg='white', bg='#7E7E7E')
        btn8.place(x=22, y=190)

        px = PanedWindow(width=400, height=700, bg='silver')
        px.place(x=1100, y=130)

        hd =PanedWindow(px, width=350, height=50, bg='white')
        hd.place(x=20, y=40)

        orderlist = Label(px, text='Order List', font='Inter 15 bold', fg='black', bg='white')
        orderlist.place(x=40, y=50)

        clearbtn = Button(px, text='CLEAR', font="Inter 15 bold", fg='white', bg='#5A3737')
        clearbtn.place(x=280,y=44)

        nextbtn = Button(text='NEXT', font='Inter 17 bold', fg='white', bg='grey', width=10)
        nextbtn.place(x=920,y=720)

        backbtn = Button(text='BACK', font='Inter 17 bold', fg='white', bg='grey', width=10)
        backbtn.place(x=750, y=720)

        hd2 = Label(px, text='ITEM                    PRICE              QTY            SUBTOTAL',bg='silver',fg='black',font='Inter 12')
        hd2.place(x=5,y=150)

        confirmbtn = Button(px, text='CONFIRM', bg ="#5A3737", fg='white', font='Inter 18', width=25)
        confirmbtn.place(x=20,y=630)

        totalp = PanedWindow(px, width=200, height=40,bg='white')
        totalp.place(x=180, y=550)

        total = Label(totalp, text='Total', font='Inter 15', bg='white')
        total.place(x=10, y=5)


if __name__ == "__main__":
    root = Tk()
    app = UserDashboard(root)
    root.geometry("1920x1080")
    root.mainloop()