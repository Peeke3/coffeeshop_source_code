from tkinter import *


class CategoryPage:
    def __init__(self, root):
        self.root = root
        self.root.title("Category Page")

        img1 = PhotoImage(file="img/img4.png")
        pic1 = Label(image=img1, bg='#5A3737')
        pic1.photo = img1
        pic1.place(x=0, y=0)

        psr1 = PanedWindow(width=204, height=470, bg='#5A3737')
        psr1.place(x=0, y=375)

        users = Label(psr1, text='USERS', font='Inter 20', fg='white', bg='#5A3737')
        users.place(x=50, y=100)

        items = Label(psr1, text='ITEMS', font="Inter 20", fg='white', bg='#5A3737')
        items.place(x=55, y=175)

        orders = Label(psr1, text='ORDERS', font='Inter 20', fg='white', bg='#5A3737')
        orders.place(x=40, y=250)

        settings = Label(psr1, text='SETTINGS', font="Inter 20", fg='white', bg='#5A3737')
        settings.place(x=30, y=325)

        logout = Label(psr1, text='LOGOUT', font="Inter 20 bold", fg='white', bg='#5A3737')
        logout.place(x=40, y=400)

        psr2 = PanedWindow(width=1500, height=120, bg='#5A3737')
        psr2.place(x=203, y=0)

        img2 = PhotoImage(file="img/img1.png")
        logo1 = Label(image=img2, bg='#5A3737')
        logo1.photo = img2
        logo1.place(x=230, y=20)

        img3 = PhotoImage(file="img/Screenshot 2024-01-30 160342.png")
        logo2 = Label(psr2, image=img3, bg='#5A3737')
        logo2.photo = img3
        logo2.place(x=1200, y=20)

        username = Label(psr2, text="MG MG", bg="#5A3737", fg='white')
        username.config(font='Inter 15')
        username.place(x=1190, y=80)

        title = Label(text="UNIQUE TEAHOUSE", bg="#5A3737", fg='white')
        title.config(font='Inter 30 bold')
        title.place(x=320, y=35)

        txt1 = Label(text="Item Category", bg=None, fg='black')
        txt1.config(font="Inter 25 bold")
        txt1.place(x=250, y=150)

        btn1 = Button(text='Create New', width=15, font='Inter 20', fg = 'black', bg = 'silver')
        btn1.place(x=250,y=300)

        btn2 = Button(text='Delete All', width=15, font='Inter 20', fg='black', bg='silver')
        btn2.place(x=250, y=380)

        heading = Label(text="Item Name                           ID                  Action              price              Stock", font="Inter 18 bold")
        heading.place(x=600, y=200)



if __name__ == "__main__":
    root = Tk()
    app = CategoryPage(root)
    root.geometry("1920x1080")
    root.mainloop()